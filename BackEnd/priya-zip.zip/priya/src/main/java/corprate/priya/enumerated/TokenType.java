package corprate.priya.enumerated;

public enum TokenType {
    BEARER
}

